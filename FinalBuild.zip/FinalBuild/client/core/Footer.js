import React from 'react'
import AppBar from 'material-ui/AppBar'
import Toolbar from 'material-ui/Toolbar'
import Typography from 'material-ui/Typography'
import { withRouter } from 'react-router-dom'

const Footer = withRouter(({ history }) => (
    <AppBar position="static">
        <Toolbar>
            <Typography type="title" color="inherit">
            Social Networking Application
            </Typography>
        </Toolbar>
    </AppBar>
))

export default Footer;
