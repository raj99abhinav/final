import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { withStyles } from 'material-ui/styles'
import home from './../assets/images/home.jpg'
import Grid from 'material-ui/Grid'
import auth from './../auth/auth-helper'
import FindPeople from './../user/FindPeople'
import Newsfeed from './../post/Newsfeed'

const styles = theme => ({
  root: {
    flexGrow: 1,
    margin: 30,
  },
  card: {
    maxWidth: 600,
    margin: 'auto',
    marginTop: theme.spacing.unit * 5
  },
  title: {
    padding: `${theme.spacing.unit * 3}px ${theme.spacing.unit * 2.5}px ${theme.spacing.unit * 2}px`,
    color: theme.palette.text.secondary
  },
  media: {
    minHeight: 330
  }
})

class Home extends Component {
  state = {
    defaultPage: true
  }
  init = () => {
    if (auth.isAuthenticated()) {
      this.setState({ defaultPage: false })
    } else {
      this.setState({ defaultPage: true })
    }
  }
  componentWillReceiveProps = () => {
    this.init()
  }
  componentDidMount = () => {
    this.init()
  }
  render() {
    const { classes } = this.props
    return (
      <div className={classes.root}>
        {this.state.defaultPage &&
          <Grid container spacing={24}>
            <Grid item xs={6} sm={6}>
              <img src={home} height='100%' width='100%' />
            </Grid>
            <Grid item xs={1} sm={1}>
            </Grid>
            <Grid item xs={4} sm={4}>
              <h2 className="text-center text-primary">Social Network</h2>
              <br/>
              <p>
                LinkedIn is one of the most popular and widely used B2B social networking platforms today.
                It provides professionals with an opportunity to connect with other professionals in their
                industry to learn and grow together. With features that allow sharing of content, engaging
                with audiences, and recruiting talent, it’s a handy platform for B2B companies.
              </p>
            </Grid>
          </Grid>
        }
        {!this.state.defaultPage &&
          <Grid container spacing={24}>
            <Grid item xs={8} sm={7}>
              <Newsfeed />
            </Grid>
            <Grid item xs={6} sm={5}>
              <FindPeople />
            </Grid>
          </Grid>
        }
      </div>
    )
  }
}

Home.propTypes = {
  classes: PropTypes.object.isRequired
}

export default withStyles(styles)(Home)
